package com.sampleapplication.datatrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatatrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatatrackApplication.class, args);
	}

}

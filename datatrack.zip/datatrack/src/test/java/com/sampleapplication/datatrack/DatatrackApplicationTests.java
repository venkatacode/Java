package com.sampleapplication.datatrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatatrackApplicationTests {

	@Test
	void contextLoads() {
	}

}

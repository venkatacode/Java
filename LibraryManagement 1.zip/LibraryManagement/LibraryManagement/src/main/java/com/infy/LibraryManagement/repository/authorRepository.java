package com.infy.LibraryManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.LibraryManagement.entity.author;

public interface authorRepository extends JpaRepository<author,Integer>{

}
